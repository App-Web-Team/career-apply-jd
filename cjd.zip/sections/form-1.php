<!-- <div class="form-1"> -->
<div class="">
    <p class="details-heading text-capitalize">
        personal details
    </p>
    <div class="job-box">
        <input type="text" name="position" value="Graphic Designer" readonly="readonly" class="not-apply position">
        <input type="text" name="jobId" value="JPW22D-GD-1001" readonly="readonly" class="not-apply position">
    </div>


    <div class="row f-row mt-5">
        <div class="col fname-col">
            <input type="text" name="fname" id="fname" />
            <label>First Name <span class="req">&#42;</span></label>
            <i class="d-none">*fill this</i>
        </div>
        <div class="col lname-col">
            <input type="text" id="lname" name="lname" />
            <label>Last Name</label>
            <i class="d-none">*fill this</i>
        </div>
    </div>
    <div class="row f-row my-5">
        <div class="col ph-col" id="ph-col">
            <input type="" name="phNo" id="phNo" onkeydown="" />
            <label>Phone No. <span class="req">&#42;</span></label>
            <i class="d-none" id="err">*fill this</i>
        </div>
        <div class="col email-col" id="email-col">
            <input type="email" id="email" name="email" onkeydown="" />
            <label>Email <span class="req">&#42;</span></label>
            <i class="d-none" id="err-email">*fill this</i>
        </div>
    </div>
    <div class="row f-row my-5">
        <div class="col address-col">
            <input type="text" id="address" name="address" />
            <label>Address <span class="req">&#42;</span></label>
            <i class="d-none">*fill this</i>
        </div>
    </div>
    <div class="row f-row my-5">
        <div class="col state-col">
            <input type="text" id="state" name="state" />
            <label>State <span class="req">&#42;</span></label>
            <i class="d-none">*fill this</i>
        </div>
        <div class="col pincode-col">
            <input type="text" id="pincode" name="pincode" />
            <label>pincode</label>
            <i class="d-none" id="err-pin">*fill this</i>
        </div>
    </div>
    <div class="text-center">
        <button type="" class="first next first-button">
            Save & Proceed
        </button>
    </div>
</div>

<script>
</script>